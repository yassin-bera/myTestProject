export let products = [
    {
        Name :"rahim1",
        price: 700 , 
        id : 1,
        imgUrl : "../assets/1.jpg"
    },
    {
        Name:"rahim2",
        price:500 ,
        id : 2,
        imgUrl : "../assets/2.jpg"
    },
    {
        Name:"rahim3",
        price:400 ,
        id : 3,
        imgUrl : "../assets/3.jpg"
    },
    {
        Name:"rahim4",
        price:800 ,
        id : 4,
        imgUrl : "../assets/4.jpg"

    },
    {
        Name:"rahim5",
        price:900 ,
        id: 5,
        imgUrl : "../assets/5.webp"
    },
    {
        Name:"rahim6",
        price:1000 ,
        id : 6,
        imgUrl : "../assets/6.jpg"
    },
  ]